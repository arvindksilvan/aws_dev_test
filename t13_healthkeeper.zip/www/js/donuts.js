AmCharts.addInitHandler(function(chart) {

  // init holder for nested charts
  if (AmCharts.nestedChartHolder === undefined)
    AmCharts.nestedChartHolder = {};

  if (chart.bringToFront === true) {
    chart.addListener("init", function(event) {
      // chart inited
      var chart = event.chart;
      var div = chart.div;
      var parent = div.parentNode;

      // add to holder
      if (AmCharts.nestedChartHolder[parent] === undefined)
        AmCharts.nestedChartHolder[parent] = [];
      AmCharts.nestedChartHolder[parent].push(chart);

      // add mouse mouse event
      chart.div.addEventListener('mousemove', function() {

        // calculate current radius
        var x = Math.abs(chart.mouseX - (chart.realWidth / 2));
        var y = Math.abs(chart.mouseY - (chart.realHeight / 2));
        var r = Math.sqrt(x*x + y*y);

        // check which chart smallest chart still matches this radius
        var smallChart;
        var smallRadius;
        for(var i = 0; i < AmCharts.nestedChartHolder[parent].length; i++) {
          var checkChart = AmCharts.nestedChartHolder[parent][i];

          if((checkChart.radiusReal < r) || (smallRadius < checkChart.radiusReal)) {
            checkChart.div.style.zIndex = 1;
          }
          else {
            if (smallChart !== undefined)
              smallChart.div.style.zIndex = 1;
            checkChart.div.style.zIndex = 2;
            smallChart = checkChart;
            smallRadius = checkChart.radiusReal;
          }

        }
      }, false);
    });
  }

}, ["pie"]);
AmCharts.makeChart("total", {
  "type": "pie",
  "bringToFront": true,
  "dataProvider": [{
    "title": "1310 cal",
    "value": 1310,
    "color": "#EEA7C8"
  }],
  "startDuration": 0,
  "pullOutRadius": 0,
  "color": "#000000",
  "fontSize": 10,
  "titleField": "title",
  "valueField": "value",
  "colorField": "color",
  "labelRadius": -30,
  "labelColor": "#fff",
  "radius": 30,
  "innerRadius": 0,
  "labelText": "[[title]]",
  "balloonText": "[[title]] burnt today."
});

AmCharts.makeChart("inner_donut", {
  "type": "pie",
  "bringToFront": true,
  "dataProvider": [{
    "title": "",
    "value": 300,
    "color": "#330A1D"
  }, {
    "title": "",
    "value": 320,
    "color": "#9A1D58"
  }, {
    "title": "",
    "value": 450,
    "color": "#E2659F"
  }, {
    "title": "",
    "value": 240,
    "color": "#EEA7C8"
  }],
  "startDuration": 1,
  "pullOutRadius": 0,
  "color": "#000000",
  "fontSize": 12,
   "bold": true,
  "titleField": "title",
  "valueField": "value",
  "colorField": "color",
  "labelRadius": -27,
  "labelColor": "#000000",
  "radius": 90,
  "innerRadius": 75,
  "outlineAlpha": 1,
  "outlineThickness": 4,
  "labelText": "[[title]]",
  "balloonText": "[[value]] Calories burned"
});

AmCharts.makeChart("outer_donut", {
  "type": "pie",
  "bringToFront": true,
  "dataProvider": [{
    "title": "Run",
    "value": 60,
    "color": "#330A1D"
  }, {
    "title": "Swim",
    "value": 30,
    "color": "#9A1D58"
  }, {
    "title": "Cycle",
    "value": 45,
    "color": "#E2659F"
  }, {
    "title": "Gym",
    "value": 20,
    "color": "#EEA7C8"
  }],
  "startDuration": 1,
  "pullOutRadius": 0,
  "color": "#000000",
  "bold": true,
  "fontSize": 12,
  "titleField": "title",
  "valueField": "value",
  "colorField": "color",
  "labelRadius": 1,
  "labelColor": "#000000",
  "radius": 110,
  "innerRadius": 90,
  "outlineAlpha": 1,
  "outlineThickness": 4,
  "labelText": "[[title]]",
  "balloonText": "[[value]] Mins",
  "allLabels": [{
    "text": "",
    "bold": true,
    "size": 25,
    "color": "#404040",
    "x": 0,
    "align": "center",
    "y": 20
  }]
});