// Run javascript after DOM is initialized
$(document).ready(function() {

  $('#map_canvas').mapit({
    latitude:    1.395444,
    longitude:   103.872933,
    zoom:        16,
    type:        'ROADMAP',
    scrollwheel: false,
    marker: {
      latitude:   1.398046,
      longitude:  103.873186,
      icon:       'img/marker_red.png',
      title:      'Thohirah Restaurant',
      open:       false,
      center:     true
    },
    address: '<h2>Thohirah Restaurant</h2><p>258 Jalan Kayu ,Singapore</p><p>Tel.: +30 210 123 4567<br />Fax: +30 210 123 4567</p>',
    styles: 'GRAYSCALE',
    locations: [
      [1.394740, 103.874086, 'img/marker_blue.png', 'Fernvale Foilage', '<h2>Lenard Pender</h2><br> <p>Fernvale Foilage</p> <p>Exercising: 10:00am to 11:00am</p>', true, '1'],
      [1.402830, 103.871298, 'img/marker_blue.png', 'Chatsworth Kindergarten', '<h2>JiYoung Millwad</h2><br> <p>3 Piccadilly Circus Singapore 797641</p><p>Exercising: 7:00am to 10:00am</p>', false, '2'],
      [1.391488, 103.876196, 'img/marker_blue.png', 'The Seletar Mall', '<h2>Gerald Kobayashi</h2><br> <p>33 Sengkang West Ave Singapore 797653</p><p>Exercising: 6:00am to 8:00am</p>', false, '3'],
      [1.387383, 103.852752, 'img/marker_blue.png', 'Amoy Quee Camp', '<h2>Mr. Up</h2><br> <p>461 Ang Mo Kio Street 66 Singapore 567754 Ang Mo Kio Street 66</p><p>Exercising: 9:00am to 10:00am</p>', false, '4'],
      [1.387726, 103.8420215, 'img/marker_blue.png', 'Yio Chu Kang Stadium', '<h2>Mrs. Lorry</h2><br> <p>210 Ang Mo Kio Ave 9, Singapore 569777</p><p>Exercising: 9:00am to 10:00am</p>', false, '5'],
    ],
    origins: [
      ['37.936294', '23.947394'],
      ['37.975669', '23.733868']
    ]
  });
});
