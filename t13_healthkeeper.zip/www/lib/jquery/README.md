# jQuery releases

This repository contains various jQuery releases (minified and development) with the tags being the exact jQuery version.

Basically this repository provides a convenient way of including a released jQuery version in your git project as a submodule.