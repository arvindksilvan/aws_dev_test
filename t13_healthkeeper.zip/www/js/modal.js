function display_modal(){
	var modal = document.getElementById('myModal');
	modal.style.display = "block";
}
function hide_modal(){
		var modal = document.getElementById('myModal');
		window.onclick = function(event) {
			if (event.target == modal)
				modal.style.display = "none";
		}
}
function cancel_modal(){
	var modal = document.getElementById('myModal');
	modal.style.display = "none";
}