var chartData1 = [];
var chartData2 = [];
var chartData3 = [];
var chartData4 = [];

generateChartData();

function generateChartData() {
  var firstDate = new Date();
  firstDate.setMonth(10);
  firstDate.setHours(0, 0, 0, 0);

  var a1 = 1500;
  var max = 2500;
  for (var i = 0; i < 30; i++) {
    var newDate = new Date(firstDate);
    newDate.setDate(newDate.getDate() + i);

    a1 += Math.round((Math.random() < 0.5 ? 1 : -1) * Math.random() * 10);
   

    chartData1.push({
      "date": newDate,
      "value": a1,
      "volume": max
    });
  }
}

var chart = AmCharts.makeChart("chartdiv", {
  "type": "stock",
  "theme": "light",
  "dataSets": [{
    "fieldMappings": [{
      "fromField": "value",
      "toField": "value"
    }, {
      "fromField": "volume",
      "toField": "volume"
    }],
    "dataProvider": chartData1,
    "categoryField": "date"
  }],
 "panels": [ {
    "showCategoryAxis": false,
    "title": "kcal",
    "percentHeight": 70,
    "stockGraphs": [ {
      "id": "g1",
      "valueField": "value",
      "comparable": false,
      "compareField": "value",
      "balloonText": "[[title]]:<b>[[value]]</b>",
      "compareGraphBalloonText": "[[title]]:<b>[[value]]</b>"
    } ],
    "stockLegend": {
      "periodValueTextComparing": "[[percents.value.close]]%",
      "periodValueTextRegular": "[[value.close]]"
    }
  }],
} );