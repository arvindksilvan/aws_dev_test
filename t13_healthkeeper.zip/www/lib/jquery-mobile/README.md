jquery-mobile-release
=====================

This repository contains various jQuery mobile releases (minified and development) with the tags being the exact jQuery mobile version.

Basically this repository provides a convenient way of including a released jQuery mobile version in your git project as a submodule.
