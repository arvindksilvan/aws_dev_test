function initalizeNav(){
	document.getElementById("mySidenav").style.height = "60vh";
}
function openNav() {
	document.getElementById("mySidenav").style.height = "60vh";
    document.getElementById("mySidenav").style.width = "30%";
    
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
